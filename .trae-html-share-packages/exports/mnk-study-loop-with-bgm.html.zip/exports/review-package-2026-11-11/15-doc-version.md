# 补充项 E：v1 → v2 改动与 HTML 同一性

状态：【已存在·附原文】

## 方案文档版本

| 版本 | 路径 | 所在提交 |
|---|---|---|
| v1 | `15-doc-version/ai-backend-security-plan-v1.md` | `0510ebe` |
| v2 | `15-doc-version/ai-backend-security-plan-v2.md` | `5210488`（当前工作文件） |

差异：`15-doc-version/v1-to-v2.diff`，统计为 **138 行新增、154 行删除**（同一文件重写）。

## v1 → v2 的主要改动

1. 标题从“AI 后端安全方案”改为“AI 后端与密钥方案”。
2. 核心问题从 1 个扩展为 3 个：密钥泄露、只调免费模型、转 App。
3. 新增“四层限制”（渠道层、令牌层、边缘层、监控层），明确付费模型在网关里不存在。
4. 密钥清单拆分为：2 把业务密钥（K1/K2）＋ 3 个系统凭据（K3/K4/K5）。
5. 新增“每天账单为 0、关闭自动充值、余额保持 0”的兜底。
6. 新增设备令牌 JWT 的 App 方案。
7. P0 清单从 20 项压缩为 12 项。

注意：v1 里“5 个密钥”的表述已被 v2 更正为“2 个业务密钥 + 3 个系统凭据”。

## HTML 同一性

| 文件 | MD5 |
|---|---|
| `/workspace/study-loop/index.html` | `7073de7d746d1fb0e7d6fdac3943301a` |
| `/workspace/exports/mnk-study-loop-with-bgm.html` | `7073de7d746d1fb0e7d6fdac3943301a` |

结论：**同一份文件**，无差异。
